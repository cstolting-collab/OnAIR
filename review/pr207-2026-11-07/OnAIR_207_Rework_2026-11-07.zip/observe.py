"""Bounded real-library checks; invoked with a repository checkout and output path."""
import contextlib
import copy
import hashlib
import io
import itertools
import json
import math
from pathlib import Path
import random
import sys

root = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(root))
import numpy as np
import simdkalman
from onair.data_handling.parser_util import floatify_input
from onair.services.service_manager import ServiceManager
from plugins.kalman.kalman_plugin import Plugin

assert isinstance(simdkalman.__file__, str)
ServiceManager({})
states = []

def record(identifier, family, check):
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            checks = check()
        state = dict(id=identifier, family=family, status='ok', checks=checks)
    except Exception as exc:
        state = dict(id=identifier, family=family, status='error', checks={}, error=type(exc).__name__)
    state['contract'] = 'onair-followup-v1'
    states.append(state)


def evaluate_plugin(p, expected):
    before = copy.deepcopy(p.frames)
    residuals = p._generate_residuals()
    again = p._generate_residuals()
    reference = []
    for history in expected:
        if len(history) < 3:
            reference.append(0.0)
        else:
            kf = simdkalman.KalmanFilter(
                state_transition=[[1, 1], [0, 1]], process_noise=np.diag([0.1, 0.1]),
                observation_model=np.array([[1, 0]]), observation_noise=1.0)
            predicted = kf.predict([history[1:-1]], 1).observations.mean[0, 0]
            reference.append(float(abs(predicted-history[-1])))
    flags = [h for h, r in zip(p.headers, reference) if h.upper() != 'TIME' and r > p.residual_threshold]
    return {
        'policy': p.frames == expected and all(math.isfinite(v) for f in p.frames for v in f),
        'complete': residuals.shape == (len(p.headers),) and bool(np.isfinite(residuals).all()),
        'correct': bool(np.allclose(residuals, reference, rtol=1e-12, atol=1e-12)) and p.render_reasoning() == flags,
        'stable': p.frames == before and bool(np.array_equal(residuals, again)),
    }

for count in range(1, 5):
    for lengths in itertools.product(range(6), repeat=count):
        def check(lengths=lengths):
            p = Plugin('lengths', ['TIME'] + [f'S{i}' for i in range(1, len(lengths))], window_size=5)
            expected = [[float((i+1)*10+j*2+(50 if j==n-1 else 0)) for j in range(n)] for i,n in enumerate(lengths)]
            for row in itertools.zip_longest(*expected, fillvalue='-'):
                p.update(row)
            return evaluate_plugin(p, expected)
        record('lengths-'+'-'.join(map(str,lengths)), 'lengths', check)

rng = random.Random(20261107)
for stream in range(40):
    count = rng.randint(1, 6)
    window = rng.randint(3, 8)
    p = Plugin('stream', ['TIME']+[f'S{i}' for i in range(1,count)], window_size=window)
    expected = [[] for _ in range(count)]
    for step in range(25):
        row=[]
        for i in range(count):
            v = rng.choice([None, '-', float('nan'), 10**309, -(10**1000), 10**5000]) if rng.random()<0.25 else rng.uniform(-100,100)
            row.append(v)
        reject = step % 11 == 0
        if reject:
            row.append(42)
        else:
            for i,v in enumerate(row):
                if isinstance(v,float) and math.isfinite(v):
                    expected[i].append(v)
                    expected[i][:] = expected[i][-window:]
        def check(p=p,row=row,expected=copy.deepcopy(expected)):
            p.update(row)
            return evaluate_plugin(p,expected)
        record(f'stream-{stream}-{step}', 'stream', check)

for exponent in [0, 1, 16, 100, 307, 308, 309, 310, 1000, 5000] + [rng.randint(309,6000) for _ in range(54)]:
    for sign in (-1,1):
        for remove in (False,True):
            value = sign*10**exponent
            def check(value=value,remove=remove,exponent=exponent):
                source=[1,value,-2]
                result=floatify_input(source,remove_str=remove)
                if exponent <= 308:
                    valid=result == [1.0,float(value),-2.0]
                elif remove:
                    valid=result == [1.0,-2.0]
                else:
                    valid=len(result)==3 and result[0]==1 and math.isnan(result[1]) and result[2]==-2
                return dict(policy=valid,complete=valid,correct=valid,stable=source==[1,value,-2])
            record(f'parser-{len(states)}-{exponent}-{sign}-{remove}', 'parser', check)

counts={}
for s in states:
    c=counts.setdefault(s['family'],dict(passed=0,failed=0))
    c['passed' if s['status']=='ok' and all(s['checks'].values()) else 'failed']+=1
result=dict(root=str(root), seed=20261107, numpy=np.__version__, simdkalman_file=simdkalman.__file__,
            source_sha256={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [root/'onair/data_handling/parser_util.py',root/'plugins/kalman/kalman_plugin.py']},
            counts=counts, states=states,
            scope='Scalar reference preserves PR207 default prior. Does not validate physical accuracy, missing-time alignment, freshness, or all numerical extremes.')
Path(sys.argv[2]).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='states'}))
