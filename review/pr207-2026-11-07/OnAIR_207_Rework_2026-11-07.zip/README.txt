NASA OnAIR #207 — focused follow-up rework
November 7, 2026

RESULT
The existing unequal-history correction is retained. This rework adds protection
against numeric conversion overflow and failures while formatting missing-data
warnings. It also declares the missing Hypothesis test dependency and fixes the
formatting check in the PR's test files. No runtime dependency was added.

These are prepared local changes, not a new upstream submission. The original
PR is mrizvi96's work. The published unequal-history follow-up is credited
separately. NASA's human review requirement has not been satisfied by this
AI-assisted pass. CLA status was not verified in this task.

CURRENT UPSTREAM STATUS
PR #207 is still open and draft at 243644b3e51d46d159bb98668a1241b01934cbb9.
No formal reviews or new maintainer requests were present. The only conversation
comment was our November 2 reproduction. Unit-test and lint/format workflows
both say action_required with zero jobs, so they provide no code verdict.
NASA's October 29 contribution guidance requests brief, human-reviewed code and
commentary. There is no evidence that a specific new feature is being requested.

WHAT CHANGED
1. Existing public correction 9f6f487: group ready channels by retained history
   length and restore residuals to their original header positions. This handles
   missing first/second channels and unequal ready windows.
2. New parser correction 8b39bfb: an integer outside float range follows the
   existing missing-data policy (NaN or removal). If repr() exceeds Python's
   integer conversion limit, the warning uses the value's type instead. Valid
   neighboring readings remain intact. Sixteen parser cases and two additional
   real-simdkalman cases cover these boundaries and positive controls.
3. New dependency correction b98f60d: declare Hypothesis, already imported by
   PR207's property tests. The documented clean install previously failed test
   collection in two modules with ModuleNotFoundError.
4. Formatting 33b1f35: four PR207 test files now pass Black. Their syntax trees
   were checked before and after and are identical. Kept in a separate commit.

VALIDATION
Python 3.12.14, NumPy 2.5.4, simdkalman 1.0.4. Exact versions are in
 environment-lock.txt. A new virtual environment was installed from the original
requirements.txt; collection failed on the missing dependency. Installing the
reworked declared requirements then allowed the complete suite to run.

Check                                      Original PR207       Reworked
Full suite + identical regression tests    405 pass / 22 fail   427 pass / 0 fail
Retained lengths 0–5, 1–4 channels          132 pass / 1422 fail 1554 pass / 0 fail
40 streams, 25 updates each                281 pass / 719 fail  1000 pass / 0 fail
Signed integer boundaries, both policies   24 pass / 232 fail   256 pass / 0 fail
Repository Black check                    5 files fail        all 81 files pass

The 427 test identities match, with no skips. The previous published follow-up
alone passed its previous 409 tests in a fresh execution; adding the new focused
cases exposed 17 failures and one passing control. The larger baseline comparison
also includes the five previously known predictor failures. These counts are
failing scenarios, not distinct defects. Stream failures can cascade because a
missed update affects later history.

The independent observer runs outside pytest's mocked simdkalman process.
It compares each ready channel against an independent scalar call to the real
dependency, checks header labels, finite retained windows, repeatable rendering,
and unchanged history after rendering. It uses seed 20261107. The scalar oracle
intentionally preserves PR207's existing numerical formula.

The coverage command reports 100% line/branch coverage, but the legacy suite
uses mocks; this number is not proof of end-to-end correctness. Repository pylint
was also run and returns success under its existing exit-zero=True configuration,
with advisory diagnostics remaining. It is not warning-free. The Python 3.8–3.11
hosted matrix was not executed locally.

CML
The actual, unchanged CML StateGovernance public runtime was used, pinned to
8331c3b1ac6450b12e8a944bd29c629e0f21ae4d. All 76 selected source-file Git blob hashes
were reverified. The Python observer computes four acceptance predicates: policy,
complete, correct, stable. CML enforces those predicates and the contract/status.

Original PR207: 437/2810 accepted. Rework: 2810/2810 accepted. Eleven negative
controls were rejected without changing accepted state or adding accepted
provenance. Ordinary host logic and CML agreed on all 5620 before/after decisions.
A deliberately dishonest passing predicate was accepted, documenting the trusted
adapter limit. CML does not independently infer telemetry physics, prove all
inputs safe, or replace a human reviewer. CML was not added to OnAIR, and its
private source is not included or newly published by this package.

LIMITS AND NEXT STEP
This follow-up preserves the predictor formula. Initial-state correction #205
belongs to its existing author and remains separate. Stale-history labels,
warm-up zeros, missing-sample time alignment, and overflow during prediction
from extreme finite floats remain outside this patch. No live telemetry, flight
hardware, NASA acceptance, performance gain, or 100% potential is demonstrated.

Recommended handoff: have a human review the small functional changes and the
brief draft, then offer the patch series to #207's author. The original PR's
author controls draft readiness; NASA controls upstream workflow approval.
No competing PR, comment, email, or branch update was published in this rework.

PATCHES AND SOURCE
The four patches apply in order to PR207 head 243644b3. If starting from the
already-published 9f6f487 follow-up, apply patches 0002–0004 only.
Final local commit: 33b1f35192025bcb4e9b1a49c431851d5062bedf
Final Git tree: 3a54d27c31c8571361e19409c919b01aab200b9a
Patch application was checked in a separate worktree and produced that same tree.
Source hashes and exact outcomes are in source-and-results.json.

PRIMARY SOURCES
https://github.com/nasa/OnAIR/pull/207
https://github.com/nasa/OnAIR/pull/207#issuecomment-6568542438
https://github.com/cstolting-collab/OnAIR/commit/9f6f4877118df3e48bb80f0649595ea5c3feda12
https://github.com/nasa/OnAIR/pull/205
https://github.com/nasa/OnAIR/issues/208
https://github.com/nasa/OnAIR/blob/4c457638f0c7463682bef9a6bdf34c6a3e602180/README.md#contributing
