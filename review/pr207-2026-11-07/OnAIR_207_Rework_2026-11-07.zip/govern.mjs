import assert from 'node:assert/strict';
import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {StateGovernance} from 'cml-reference-compiler/runtime';

const rules = [
  {id:'contract',assert:{path:'contract',op:'equals',value:'onair-followup-v1'}},
  {id:'completed',assert:{path:'status',op:'equals',value:'ok'}},
  ...['policy','complete','correct','stable'].map(key=>({id:key,
    assert:{path:`checks.${key}`,op:'equals',value:true}})),
];
const hostAccepts = s => s.contract==='onair-followup-v1' && s.status==='ok' &&
  ['policy','complete','correct','stable'].every(k=>s.checks[k]===true);
const reports=[];
let agreement=0;
for (const mode of ['before','after']) {
  const bytes=readFileSync(new URL(`observations-${mode}.json`, import.meta.url));
  const observations=JSON.parse(bytes);
  const sha256=createHash('sha256').update(bytes).digest('hex');
  const cml=new StateGovernance();
  const decisions=observations.states.map(s=>{
    const result=cml.evaluateTransition({candidateState:s,invariants:rules,
      provenanceRecord:{id:s.id,stateKey:'checks',value:s.checks,status:'validated',
        source:{type:'host_observation',sha256},
        evidence:{cmlCommit:'8331c3b1ac6450b12e8a944bd29c629e0f21ae4d'}}});
    assert.equal(result.accepted,hostAccepts(s));
    agreement++;
    if(result.accepted)cml.commitProvenance(result.provenanceRecord);
    return {id:s.id,accepted:result.accepted,violations:result.validation.violations.map(v=>v.id)};
  });
  const report={mode,sha256,total:decisions.length,
    accepted:decisions.filter(d=>d.accepted).length,
    provenanceRecords:cml.provenance.size(),rules,decisions};
  writeFileSync(new URL(`decisions-${mode}.json`,import.meta.url),JSON.stringify(report,null,2)+'\n');
  reports.push({...report,decisions:undefined,rules:undefined});
}
const good=JSON.parse(readFileSync(new URL('observations-after.json',import.meta.url))).states[0];
const cml=new StateGovernance();
const positive=cml.evaluateTransition({candidateState:good,invariants:rules,
  provenanceRecord:{id:'positive',stateKey:'checks',value:good.checks,status:'validated',source:'control'}});
assert.equal(positive.accepted,true);
cml.commitProvenance(positive.provenanceRecord);
const before=JSON.stringify(positive.state);
const controls=[];
const mutations=[
  ['exception',s=>s.status='error'],['wrong-contract',s=>s.contract='wrong'],
  ...['policy','complete','correct','stable'].flatMap(k=>[
    [k,s=>s.checks[k]=false],[`missing-${k}`,s=>delete s.checks[k]]]),
  ['nonfinite',s=>s.raw=NaN],
];
for (const [name,mutate] of mutations) {
  const candidate=structuredClone(good);mutate(candidate);
  let rejected;
  try { rejected=!cml.evaluateTransition({previousState:positive.state,candidateState:candidate,invariants:rules}).accepted; }
  catch(e) {assert.equal(name,'nonfinite');rejected=true;}
  assert.equal(rejected,true,name);
  assert.equal(JSON.stringify(positive.state),before);
  assert.equal(cml.provenance.size(),1);
  controls.push({name,rejected,previousUnchanged:true,rejectedProvenanceAppended:false});
}
const deceptive=structuredClone(good);deceptive.bad_residual=-999;
assert.equal(cml.evaluateTransition({candidateState:deceptive,invariants:rules}).accepted,true);
const summary={engine:'CML StateGovernance public runtime',
  sourceCommit:'8331c3b1ac6450b12e8a944bd29c629e0f21ae4d',reports,
  negativeControls:controls,plainHostDecisionsMatching:agreement,
  limit:'CML enforces predicates calculated by the Python observer. It does not independently validate telemetry physics; false metrics with falsely passing predicates can be accepted. No OnAIR CML dependency was added.'};
writeFileSync(new URL('cml-summary.json',import.meta.url),JSON.stringify(summary,null,2)+'\n');
console.log(JSON.stringify({...summary,negativeControls:controls.length}));
